int(input("digite a hora inicial: "))
int(input("digite o minuto inicial: "))
int(input("digite a hora final: "))
int(input("Digite o minuto final: "))

if 