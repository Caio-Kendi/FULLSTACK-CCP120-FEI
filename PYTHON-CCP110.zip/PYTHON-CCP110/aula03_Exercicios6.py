idade_veiculo=int(input("Digite a idade do veiculo em anos: "))
if idade_veiculo <= 3:
    print("o veiculo é novo")
else:
    print("o veiculo é velho")


