from math import ceil

# entradas 
altura = float(input("altura: "))
raio = float(input("raio: "))



# calculos
area_base = 3.1415 * raio ** 2
area_lateral = 2 * 3.1415 * raio * altura
area_total = area_lateral + area_base
qtde_litros = area_total / 3
qtde_latas = ceil(qtde_litros / 5)



if qtde_latas == 1:
    preco = 50
elif qtde_latas == 2:
    preco = 48
elif qtde_latas == 3:
    preco = 46
elif qtde_latas > 3:
    preco = 45

preco_total = preco * qtde_latas


#saidas

print(f"area a ser pintada: {area_total:.2f} m²")
print(f"qtde de tinta necessaria: {qtde_litros:.2f} litros")
print(f"qtde de latas de tinta necessaria: {qtde_latas} latas")
print(f"preco unitario: R$ {preco:.2f}")
print(f"preco total: R${preco_total:.2f}")