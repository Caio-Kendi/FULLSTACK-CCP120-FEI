primeiro_produto = int(input("Digite o valor do primeiro produto: "))
segundo_produto = int(input("Digite o valor do segundo produto: "))
terceiro_produto = int(input("Digite o valor do terceiro produto: "))
soma_produtos = (primeiro_produto + segundo_produto + terceiro_produto)

if soma_produtos > 500:
    print(f"Desconto: {soma_produtos * 0.80}")
else:
    print(f"Desconto: {soma_produtos * 0.90}")    
