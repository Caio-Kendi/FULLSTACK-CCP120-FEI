codigo_produto = float(input("Digite o código do produto:"))
quantidade_produto = float(input("Digite a quantidade do produto:"))
if codigo_produto == 1:
    preco = 6.00
elif codigo_produto == 2:
    preco = 6.50
elif codigo_produto == 3:
    preco = 5.00 
elif codigo_produto == 4:
    preco = 3.00
elif codigo_produto == 5:
    preco = 2.00

total = (preco * quantidade_produto)
print(f"total {total:.2f}")