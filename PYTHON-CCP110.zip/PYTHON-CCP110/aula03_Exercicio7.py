distancia = int(input("Digite a distancia percorrida: "))

if distancia <=200:
    preco = distancia * 0.50
else:
    preco = 200 * 0.50 + (distancia - 200) * 0.45

print(f"O preco da passagem é: R${preco:.2f}")