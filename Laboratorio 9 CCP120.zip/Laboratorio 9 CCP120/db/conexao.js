const mongoose = require('mongoose');

// 🔹 Substitua pela sua URL do MongoDB Atlas
const uri = "mongodb+srv://caionakashima53_db_user:%40Caio2003@cluster0.etxejqk.mongodb.net/?appName=Cluster0"
mongoose.connect(uri)
  .then(() => console.log("✅ Conectado ao MongoDB Atlas!"))
  .catch(err => console.error("❌ Erro ao conectar:", err));

// Modelo de post
const PostSchema = new mongoose.Schema({
  titulo: String,
  resumo: String,
  conteudo: String
});

const Post = mongoose.model('Post', PostSchema);

// Funções de banco
async function inserirPost(titulo, resumo, conteudo) {
  const novoPost = new Post({ titulo, resumo, conteudo });
  await novoPost.save();
}

async function buscarPosts() {
  return await Post.find().sort({ _id: -1 });
}

module.exports = { inserirPost, buscarPosts };
