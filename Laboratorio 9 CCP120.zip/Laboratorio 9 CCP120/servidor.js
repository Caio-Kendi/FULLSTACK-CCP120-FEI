const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const { inserirPost, buscarPosts } = require('./db/conexao');

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.get('/', (req, res) => res.redirect('/blog'));

app.get('/blog', async (req, res) => {
  const posts = await buscarPosts();
  res.render('blog', { posts });
});

app.get('/cadastrar', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'cadastrar_post.html'));
});

app.post('/cadastrar', async (req, res) => {
  const { titulo, resumo, conteudo } = req.body;
  await inserirPost(titulo, resumo, conteudo);
  res.redirect('/blog');
});

app.listen(80, () => console.log('Servidor rodando na porta 80...'));
