// --- Canvas Casa ---
let canvasCasa = document.getElementById('canvasCasa');
let ctxCasa = canvasCasa.getContext('2d');

// Casa Marrom
ctxCasa.fillStyle = 'SaddleBrown';
ctxCasa.fillRect(180,200,150,150);

// Janela Azul
ctxCasa.fillStyle = '#61BBFB';
ctxCasa.fillRect(200,230,40,40);
ctxCasa.fillRect(270,230,40,40);

// Porta
ctxCasa.fillStyle = "#5F4525";
ctxCasa.fillRect(240,270,30,80);

// Asfalto
ctxCasa.fillStyle = "Grey";
ctxCasa.fillRect(0,350,600,500);

// Telhado
ctxCasa.fillStyle = "#EC6E52";
ctxCasa.beginPath();
ctxCasa.moveTo(180,200);
ctxCasa.lineTo(330,200);
ctxCasa.lineTo(255,120);
ctxCasa.fill();
ctxCasa.closePath();

// Árvores
ctxCasa.fillStyle = "SaddleBrown";
ctxCasa.fillRect(70,280,35,70);
ctxCasa.fillRect(410,370,35,70);

ctxCasa.fillStyle = "Green";
ctxCasa.beginPath();
ctxCasa.arc(88, 260, 50, 0, 2 * Math.PI);
ctxCasa.fill();
ctxCasa.beginPath();
ctxCasa.arc(426, 350, 50, 0, 2 * Math.PI);
ctxCasa.fill();

// Sol
ctxCasa.fillStyle = "Yellow";
ctxCasa.beginPath();
ctxCasa.arc(390, 100, 65, 0, 2 * Math.PI);
ctxCasa.fill();

// Cachoeira
ctxCasa.fillStyle = "#598CFA";
ctxCasa.fillRect(0,350,70,200);
ctxCasa.fillRect(0,420,180,200);
ctxCasa.beginPath();
ctxCasa.arc(-5, 360, 75, 0, 2.5 * Math.PI);
ctxCasa.fill();
ctxCasa.beginPath();
ctxCasa.arc(180, 495, 75, 0, 2.5 * Math.PI);
ctxCasa.fill();


// --- Canvas Figuras ---
let canvasFiguras = document.getElementById('canvasFiguras');
let ctxFig = canvasFiguras.getContext('2d');

// Quadrados
ctxFig.fillStyle = "blue";
ctxFig.fillRect(50, 50, 50, 50);
ctxFig.fillStyle = "red";
ctxFig.fillRect(400, 50, 50, 50);
ctxFig.fillStyle = "cyan";
ctxFig.fillRect(50, 250, 50, 50);
ctxFig.fillRect(400, 250, 50, 50);
ctxFig.fillStyle = "yellow";
ctxFig.fillRect(50, 400, 50, 50);
ctxFig.fillStyle = "black";
ctxFig.fillRect(400, 400, 50, 50);
ctxFig.fillStyle = "red";
ctxFig.fillRect(225, 225, 50, 50);

// Linhas conectando quadrados
ctxFig.beginPath();
ctxFig.strokeStyle = "blue";
ctxFig.moveTo(75, 75);
ctxFig.lineTo(250, 250);
ctxFig.stroke();
ctxFig.beginPath();
ctxFig.strokeStyle = "red";
ctxFig.moveTo(425, 75);
ctxFig.lineTo(250, 250);
ctxFig.stroke();
ctxFig.beginPath();
ctxFig.strokeStyle = "green";
ctxFig.moveTo(75, 275);
ctxFig.lineTo(250, 250);
ctxFig.moveTo(425, 275);
ctxFig.lineTo(250, 250);
ctxFig.stroke();
ctxFig.closePath();

// Círculos
ctxFig.fillStyle = "yellow";
ctxFig.beginPath();
ctxFig.arc(175, 375, 25, 0, 2 * Math.PI);
ctxFig.fill();
ctxFig.beginPath();
ctxFig.arc(325, 375, 25, 0, 2 * Math.PI);
ctxFig.fill();

// Semicírculos
ctxFig.strokeStyle = "green";
ctxFig.lineWidth = 2;
ctxFig.beginPath();
ctxFig.arc(250, 350, 50, Math.PI, 2 * Math.PI);
ctxFig.stroke();
ctxFig.beginPath();
ctxFig.arc(250, 350, 50, 0, Math.PI);
ctxFig.stroke();

// Círculo central ciano
ctxFig.fillStyle = "cyan";
ctxFig.beginPath();
ctxFig.arc(250, 150, 25, 0, 2 * Math.PI);
ctxFig.fill();
